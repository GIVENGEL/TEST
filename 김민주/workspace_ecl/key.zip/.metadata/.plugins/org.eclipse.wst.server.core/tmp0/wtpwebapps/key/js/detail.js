$(function(){
	
	
	let buy=$('#buy');
	
	buy.click(function(){
		location.href = 'end.html';
	})
});